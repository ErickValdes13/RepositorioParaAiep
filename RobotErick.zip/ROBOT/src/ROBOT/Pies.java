package ROBOT;

public class Pies {
	
	String TipoDePie;
	String Dedos;
	String Tamano;
	
	public String getTipoDePie(String TipoDePie) {
		this.TipoDePie = TipoDePie;
			
		return TipoDePie;
	}

	public void setTipoDePie(String tipoDePie) {
		TipoDePie = tipoDePie;
	}

	public String getDedos() {
		return Dedos;
	}

	public void setDedos(String dedos) {
		Dedos = dedos;
	}

	public String getTamano() {
		return Tamano;
	}

	public void setTamano(String tamano) {
		Tamano = tamano;
	}

	public void caminar () {
		
		System.out.print("El robot esta tomando elementos");
	} 
	

}

package ROBOT;

public class Manos {
	
	String dedos;
	public String getDedos() {
		return dedos;
	}



	public void setDedos(String dedos) {
		this.dedos = dedos;
	}



	public String getUnas() {
		return unas;
	}



	public void setUnas(String unas) {
		this.unas = unas;
	}



	public String getAccesorios() {
		return accesorios;
	}



	public void setAccesorios(String accesorios) {
		this.accesorios = accesorios;
	}



	String unas;
	String accesorios;
	
	
	
	public void tomar() {
		
		System.out.print("El robot esta tomando elementos");
	}
	
	
	

}

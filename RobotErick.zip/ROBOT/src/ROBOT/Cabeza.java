package ROBOT;

public class Cabeza {

	String Pelo;
	
	
	public String getPelo() {
		return Pelo;
	}

	public void setPelo(String pelo) {
		Pelo = pelo;
	}

	public String getTamano() {
		return Tamano;
	}

	public void setTamano(String tamano) {
		Tamano = tamano;
	}

	public String getMaquillaje() {
		return Maquillaje;
	}

	public void setMaquillaje(String maquillaje) {
		Maquillaje = maquillaje;
	}

	String Tamano;
	String Maquillaje;
	
public void Hablar () {
		
		System.out.print("El robot esta hablando");
	} 
	
	


}

package ROBOT;

public class Robot {
	
	String manos;
	String pies;
	String torso;
	String cabeza;
	
	public String getManos() {
		return manos;
	}

	public void setManos(String manos) {
		this.manos = manos;
	}

	public String getPies() {
		return pies;
	}

	public void setPies(String pies) {
		this.pies = pies;
	}

	public String getTorso() {
		return torso;
	}

	public void setTorso(String torso) {
		this.torso = torso;
	}

	public String getCabeza() {
		return cabeza;
	}

	public void setCabeza(String cabeza) {
		this.cabeza = cabeza;
	}

	public void caminar () {
		System.out.print("El robot esta caminando");
		

	}
		
}


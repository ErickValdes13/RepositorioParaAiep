package ROBOT;

public class OUTFIT {

	String zapatos;
	String polera;
	String pantalon;
	String trajes; 
	String OutfitPreestablecido;

public void TipoDeVesrtuario () {
		
		System.out.print("El robot esta usando");
	}  
	
	
}
